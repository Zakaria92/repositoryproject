"use strict";
/*global $ */
$(document).keydown(function (a) {
    if((a.which) === 37) {
            $("#muis").attr('src', 'img/stap2.png');
                $("#muis").animate({ "left": "-=8px" }, 0);}
		if((a.which) === 38) {
            $("#muis").attr('src', 'img/stap2.png');
				$("#muis").animate({ "top": "-=8px" }, 0);}
		if((a.which) === 39) {
		  $("#muis").attr('src', 'img/stap2.png');
				$("#muis").animate({ "left": "+=8px" }, 0);}
         if((a.which) === 40) {
            $("#muis").attr('src', 'img/stap2.png');
				$("#muis").animate({ "top": "+=8px" }, 0); }
});
