"use strict";
/*global $ */
var wall = "img/mur.jpg";
var hole = "img/home.jpg"
var antalSeconden = 0;
var widthWorld = 0;
var heightWorld = 0;
var level = 0;
var WORLD1;
var timer;
var world;
var heightblck = 0;
var widthblck = 0;
var walls;
var mouse;
var cheescollitions =0;
var catisalive = false;
var leveltijd = [30 , 40, 50];
var cheestoeat = [6 , 12, 20];
// spelen met de indexen zodat ik met de direct kan werken.
// dit declareer ik hier zodat het overal kan gebruikt worden
// jason file internet
var cheespos = {x:0 , y:0};
var holepos = {x:0 , y:0};
var catpos = {x:0 , y:0};
//-------------
var posxArray;
var posyArray;
var WORLDS = [
             
             [ [1,1,1,0,0,0,0,0,1,1,1,1,1,1,1],
               [1,0,2,0,0,0,0,0,0,0,0,0,0,0,1],
               [1,1,1,1,1,1,0,1,1,1,1,1,1,0,1],
               [1,0,0,0,0,1,0,0,0,0,1,0,0,0,1],
               [1,0,1,0,0,1,1,1,1,0,1,1,1,0,1],
               [1,0,1,0,0,0,0,0,0,0,1,0,0,0,1],
               [1,0,1,1,1,1,0,1,1,1,1,0,1,1,1],
               [1,0,1,0,0,1,0,1,0,0,1,0,0,0,1],
               [1,0,1,0,0,1,1,1,0,0,1,1,1,0,1],
               [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
               [1,1,1,1,1,1,1,5,1,1,1,1,1,1,1]

            ],
            [  [1,0,1,1,1,1,1,1,1,1,1,1,1,1,1],
               [1,2,1,0,0,0,1,0,0,0,1,0,0,0,1],
               [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1],
               [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1],
               [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1],
               [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1],
               [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1],
               [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1],
               [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1],
               [1,0,0,0,1,0,0,0,1,0,0,0,1,0,1],
               [1,1,1,1,1,1,1,1,1,1,1,1,1,5,1]

            ]
,
            [  [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
               [1,2,0,0,0,0,0,0,0,0,0,0,0,0,1],
               [1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
               [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
               [1,0,1,1,1,1,1,1,1,1,1,1,1,1,1],
               [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
               [1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
               [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
               [1,0,1,1,1,1,1,1,1,1,1,1,1,1,1],
               [1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
               [1,1,1,1,1,1,1,1,1,1,1,1,1,5,1]

            ]

            ]

$(function () {
    $(document).ready(function(){
   
    world = $("#spelruimte")
    heightWorld = world.height();
    widthWorld  = world.width();
    
    
    changelevel();
    randominworldchees();
  



    });

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}
function collisionArray(x ,y)
{  //index van de array daarmaa kan hij niet naar -1 dus uit het spel lopen (links of boven)
    if(x < 0 || y < 0)
  {
    return true;
  }
    // out of world check rechts 
    // kijk hoeveel rijen           kijk hoeveel kollomen in het rij array
  if(y > WORLD1.length - 1  || x > WORLD1[y].length - 1)
  {
    return true;
  }
        // als hij in de speelruimte is en een muur tegenkomt mag hij ook niet verder
    return WORLD1[y][x] == 1;
}

function checkpos(val , x , y)
{
  return val.x == x && val.y == y;
}


function randominworldchees()
{   var y , x;
    var good = 1;
 // good wilt zeggen we hebben een positite gevonden waar er niks is (value == 0)
    while (good != 0) {
       y = getRandomInt(0 , WORLD1.length);
       x = getRandomInt(0 , WORLD1[y].length);
       good = WORLD1[y][x];
    }
    
 // dit houden we bij voor de collision check 
    cheespos.x = x;
    cheespos.y = y;
 

    $("#cheese").css({ 'position' : 'absolute','left' :  widthblck*x  +'px', 
                                'top': heightblck*y  +'px',
                                 'height': heightblck +'px', 
                                 'width': widthblck  +'px'});

    

}
function changelevel()
{
    $("#timer").css("background-color", "transparent");
    $(".wall").remove();
    $(".hole").remove();
      $("#cat").css({ 'display' : 'none'});
     WORLD1  = WORLDS[level];
     heightblck = heightWorld / WORLD1.length;
    widthblck = widthWorld / WORLD1[0].length;

          // i prend le rij 
          // k prend le kolom
          
       for (var i = 0; i < WORLD1.length; ++i) {
       for (var k = 0; k < WORLD1[i].length; ++k) {

             if ( WORLD1[i][k] == 1)
             world.append('<img class="wall" src="'+ wall +'" style="position:absolute;left:' + widthblck*k+'px;top: '+heightblck*i+'px; height: '+heightblck+'px; width:'+widthblck+'px; "/>');
             if ( WORLD1[i][k] == 5)
             {
             world.append('<img class="hole" src="'+ hole +'" style="position:absolute;left:' + widthblck*k+'px;top: '+ heightblck*i+'px; height: '+heightblck+'px; width:'+widthblck+'px; "/>');  
             holepos.x = k;
             holepos.y = i;   
             }
            
             if ( WORLD1[i][k] == 2)
             {
               $("#cat").css({'left' :  widthblck*k + 2 +'px', 
                                'top': heightblck*i + 2 +'px',
                                 'height': heightblck - 4+'px', 
                                 'width': widthblck - 4 +'px',
                                 'position': 'absolute',
                                 'display' : 'none'
                                 });

                $("#muis").css({'left' :  widthblck*k + 2 +'px', 
                                'top': heightblck*i + 2 +'px',
                                 'height': heightblck - 4+'px', 
                                 'width': widthblck - 4 +'px',
                                  'position': 'absolute'});

                catpos.x = k;
                catpos.y = i;
                posxArray = k;
                posyArray = i;
             }
        }
    }
    mouse =  $("#mouse");
  
}
$(document).ready(function()
    {  
     /*voor mobile*/
     var positie = $("#muis").position();
    
    $("#gauche").click(function()
            {
        
        $("#muis").attr('src', 'img/links.gif');
            if (!collisionArray(posxArray - 1 ,posyArray))
            {
               --posxArray;
               $("#muis").css('left', posxArray * widthblck + 'px');
            }

        
        
        });
    
    
       $("#droite").click(function()
            {
        
       $("#muis").attr('src', 'img/rechts.gif');
           if (!collisionArray(posxArray + 1 ,posyArray))
            {
               ++posxArray;
               $("#muis").css('left', posxArray * widthblck + 'px');
            }

        
        
        });
    
    
    
        $("#haut").click(function()
            {
        
       $("#muis").attr('src', 'img/omhoog.gif');
             if (!collisionArray(posxArray ,posyArray - 1))
            {

               --posyArray;
               $("#muis").css('top', posyArray * heightblck + 'px');
            }
        
        });
    
   
    
          $("#bas").click(function()
            {
        
        $("#muis").attr('src', 'img/beneden.gif');
         if (!collisionArray(posxArray  ,posyArray + 1))
            {
               ++posyArray;
               $("#muis").css('top', posyArray * heightblck + 'px');
            }
    // check collision kaas
        if (checkpos(cheespos , posxArray ,posyArray))
        {
            ++cheescollitions;
            updatetext();
            randominworldchees();
        }
       // check collision kat
        if(checkpos(catpos , posxArray , posyArray) && catisalive)
        {
              world.empty();
            /*MEDIA QUERY met JAVA-script ;) !!*/
                  /* http://www.alsacreations.com/article/lire/1500-matchmedia-javascript-media-queries.html  */
              if (window.matchMedia("(min-width: 1445px)").matches) {
                             world.css( "background-image" , "url(img/dead.gif");    
                  } else {
                            world.css( "background-image" , "url(img/dead.gif");
                               world.css( "background-size", "contain");
                  }
            
             
             document.getElementById('timer').innerHTML = "TOM : 1 - JERRY : 0 ";
             
        }
         // check collision gat
        if(checkpos(holepos , posxArray , posyArray) && cheescollitions >=  cheestoeat[level])
        {
              catisalive = false;
              clearInterval(timer);
              ++level;
              if(WORLDS.length > level)
              {
                  changelevel();
                  cheescollitions;
                  randominworldchees();
                  antalSeconden += leveltijd[level];
                  timer = setInterval(tijd, 1000);
              }
              else
              { /*MEDIA QUERY met JAVA-script ;) !!*/
                  /* http://www.alsacreations.com/article/lire/1500-matchmedia-javascript-media-queries.html  */
                 world.empty();
                  if (window.matchMedia("(min-width: 1445px)").matches) {
                             world.css( "background-image" , "url(img/einde.gif");    
                  } else {
                            world.css( "background-image" , "url(img/einde.gif");
                               world.css( "background-size", "contain");
                  }
                
              }
        }

        
        });







     $(document).keydown(function (a) {
 var positie = $("#muis").position();
        

         /*VOOR COMPUTER*/

       
   
        switch (a.keyCode) {
        case 37:
         $("#muis").attr('src', 'img/links.gif');
            if (!collisionArray(posxArray - 1 ,posyArray))
            {
               --posxArray;
               $("#muis").css('left', posxArray * widthblck + 'px');
            }

                    
            break;
        case 38:
            $("#muis").attr('src', 'img/omhoog.gif');
             if (!collisionArray(posxArray ,posyArray - 1))
            {

               --posyArray;
               $("#muis").css('top', posyArray * heightblck + 'px');
            }
         
            break;
        case 39:
         $("#muis").attr('src', 'img/rechts.gif');
           if (!collisionArray(posxArray + 1 ,posyArray))
            {
               ++posxArray;
               $("#muis").css('left', posxArray * widthblck + 'px');
            }
         
            break;
        case 40:
        $("#muis").attr('src', 'img/beneden.gif');
         if (!collisionArray(posxArray  ,posyArray + 1))
            {
               ++posyArray;
               $("#muis").css('top', posyArray * heightblck + 'px');
            }
            break;
        }
         // check collision kaas
        if (checkpos(cheespos , posxArray ,posyArray))
        {
            ++cheescollitions;
            updatetext();
            randominworldchees();
        }
       // check collision kat
        if(checkpos(catpos , posxArray , posyArray) && catisalive)
        {
              world.empty();
            /*MEDIA QUERY met JAVA-script ;) !!*/
                  /* http://www.alsacreations.com/article/lire/1500-matchmedia-javascript-media-queries.html  */
              if (window.matchMedia("(min-width: 1445px)").matches) {
                             world.css( "background-image" , "url(img/dead.gif");    
                  } else {
                            world.css( "background-image" , "url(img/dead.gif");
                               world.css( "background-size", "contain");
                  }
            
             
             document.getElementById('timer').innerHTML = "TOM : 1 - JERRY : 0 ";
             
        }
         // check collision gat
        if(checkpos(holepos , posxArray , posyArray) && cheescollitions >=  cheestoeat[level])
        {
              catisalive = false;
              clearInterval(timer);
              ++level;
              if(WORLDS.length > level)
              {
                  changelevel();
                  cheescollitions;
                  randominworldchees();
                  antalSeconden += leveltijd[level];
                  timer = setInterval(tijd, 1000);
              }
              else
              { /*MEDIA QUERY met JAVA-script ;) !!*/
                  /* http://www.alsacreations.com/article/lire/1500-matchmedia-javascript-media-queries.html  */
                 world.empty();
                  if (window.matchMedia("(min-width: 1445px)").matches) {
                             world.css( "background-image" , "url(img/einde.gif");    
                  } else {
                            world.css( "background-image" , "url(img/einde.gif");
                               world.css( "background-size", "contain");
                  }
                
              }
        }

        /*¨hier vindt u een tweede manier */

        /*
    
    if((a.which) === 37) {
            $("#muis").attr('src', 'img/links.gif');
                $("#muis").animate({ "left": "-=8px" }, 0);}
		if((a.which) === 38) {
            $("#muis").attr('src', 'img/omhoog.gif');
				$("#muis").animate({ "top": "-=8px" }, 0);}
		if((a.which) === 39) {
		  $("#muis").attr('src', 'img/rechts.gif');
				$("#muis").animate({ "left": "+=8px" }, 0);}
         if((a.which) === 40) {
            $("#muis").attr('src', 'img/beneden.gif');
				$("#muis").animate({ "top": "+=8px" }, 0); }
                */
    });

});





 function tijd() {
        antalSeconden -= 1;


        if (antalSeconden <= 10 && antalSeconden % 2 == 0) {
            $("#timer").css("background-color", "red");

        } 
          if (antalSeconden <= 10 && antalSeconden % 2 != 0)
        {
            $("#timer").css("background-color", "black");

        }
     
     



        //stopt het afloop
        if (antalSeconden == 0) {
            clearInterval(timer);

            if(checkpos(holepos , posxArray , posyArray))
            {
            
              ++level;
              if(WORLDS.length > level)
              {
                  catisalive = false;
                  changelevel();
                  randominworldchees();
                  cheescollitions=0;
                  antalSeconden += leveltijd[level];
                  timer = setInterval(tijd, 1000);
              }
              else
              {
                 world.empty();µ /*MEDIA QUERY met JAVA-script ;) !!*/
                  /* http://www.alsacreations.com/article/lire/1500-matchmedia-javascript-media-queries.html  */
              if (window.matchMedia("(min-width: 1445px)").matches) {
                             world.css( "background-image" , "url(img/eindee.gif");    
                  } else {
                            world.css( "background-image" , "url(img/einde.gif");
                               world.css( "background-size", "contain");
                  }
            
                 
              }
            }
            else
            {
              alert("Hurry up the cat is comming !!")
           
             // world.empty();
               // world.css( "background-image" , "url(img/dead.gif");
             
            }
            
            
            
        }


      updatetext();
  }


function updatetext()
{
   if (antalSeconden > 9)
        //zorgt voor een update elke second. Zodat het timer ook efectief door de user kan gezien worden.
        {
            document.getElementById('timer').innerHTML = antalSeconden + " sec Cheese: " + cheescollitions + "/" + cheestoeat[level];
        } else {

            document.getElementById('timer').innerHTML = "0" + antalSeconden + " sec Cheese:"  + cheescollitions + "/" + cheestoeat[level];
        }

    if (antalSeconden == 1)

	{
	
	world.empty();
        
        
        
         /*MEDIA QUERY met JAVA-script ;) !!*/
                  /* http://www.alsacreations.com/article/lire/1500-matchmedia-javascript-media-queries.html  */
                 world.empty();
                  if (window.matchMedia("(min-width: 1445px)").matches) {
                             world.css( "background-image" , "url(img/dead.gif");    
                  } else {
                            world.css( "background-image" , "url(img/dead.gif");
                            world.css( "background-size", "contain");
                  }
                
        
        

    document.getElementById('timer').innerHTML = "YOU LOSE!!";
	}
}


$(function () {


    antalSeconden = leveltijd[level];

    timer = setInterval(tijd, 1000);



});