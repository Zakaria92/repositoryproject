"use strict";
/*global $ */




$(function()
{

    
     var antalSeconden = 100;
    
    var timer = setInterval(tijd, 1000);
    
        
        function tijd()
        {
            antalSeconden -= 1;
            
            
                if ( antalSeconden <= 10 && antalSeconden % 2 == 0 )  
                                    {
                                         $("#timer").css ("background-color", "red"); 
                              
                                    }
            
                                            else
                                                            {
                                                                    $("#timer").css ("background-color", "green");
                                                    
                                                            }
            
       
                        
           //stopt het afloop
            if(antalSeconden == 0)
                                    {  
                                        clearInterval(timer);
                                    }
            
            
            
           if (antalSeconden > 9)
            //zorgt voor een update elke second. Zodat het timer ook efectief door de user kan gezien worden.
            {
                    document.getElementById('timer').innerHTML = antalSeconden + " sec";
              }
            else
                {
                    
                    document.getElementById('timer').innerHTML = "0" + antalSeconden + " sec";
                }
    
        }
    
});