"use strict";
/*global $ */

$(function()
{

    var soundBack = $('#soundBack')[0];
    
    soundBack.play();

    
    
    
});




$(function()
  {
        //var counter = $('#TextBox').val();
        $('#AddButton').click( function() {
            var counter = $('#TextBox').val();
            counter++ ;
            $('#TextBox').val(counter);
    });
});