"use strict";
/*global $ */






        
        
    $(document).ready(function()
    {  
            var counter = 1;
            var soundBack = $('#soundBack')[0];
        
            soundBack.play();
    
            $("#buttonMute").click(function()
            {
                counter++;
                $("#theCount").text(counter);
                
                
                if(counter % 2 != 0)
                {
                    $("#buttonMute").attr("src","img/nmute.png"); 
                    soundBack.play();
                    
                   
                   
                    
                }
                
                if(counter % 2 == 0)
                {
                    $("#buttonMute").attr("src","img/mute.png");
                    soundBack.pause();
        
                }
        
            });
    
        

        
    });





