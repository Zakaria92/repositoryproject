"use strict";
/*global $ */

$(function()
{
    var limitX = 0;
    var limitY = 0;
    
    limitX;
    

$(document).keydown(function (a) {
   
    //alert(a.keyCode);
    
    var positie = $("#muis").position();
    
     switch (a.keyCode)
    {
        case 37:    $("#muis").attr('src', 'img/links.gif');
                    $("#muis").css('left', positie.left - 10 + 'px');
            
                    limitX--;
            
            
                        /*Zorgd voor het limiet van het linkse kant*/
                    $(function links()
                    {
                        if ( limitX <= -40)
                        {
                            $("#muis").css('left', positie.left + 0 + 'px');
                            limitX = -40;
                        }
                    });
                    break;
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        case 38:    $("#muis").attr('src', 'img/omhoog.gif');
				    $("#muis").css('top', positie.top - 10 + 'px');
                    
                    limitY--;
            
            /*Zorgd voor het limiet van het boven kant*/
                    $(function omhoog()
                    {
                        if ( limitY <= 0)
                        {
                            $("#muis").css('top', positie.top + 0 + 'px');
                            limitY = 0;
                        }
                    });
                    break;
            
            
            
            
            
            
            
            
        case 39:    $("#muis").attr('src', 'img/rechts.gif');
				    $("#muis").css('left', positie.left + 10 + 'px');
            
                    limitX++;
            
            
            
            
            
            
            
                    /*Zorgt voor het limiete van het rechtse kant*/
                    $(function rechts()
                    {
                        if ( limitX >= 24)
                        {
                            $("#muis").css('left', positie.left + 0 + 'px');
                            limitX = 24;
                        }
                    });
                    break;
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        case 40:    $("#muis").attr('src', 'img/beneden.gif');
				    $("#muis").css('top', positie.top + 10 + 'px');
            
            
        limitY++;
            
            
                    $(function beneden()
                    {
                        if ( limitY >= 40)
                        {
                            $("#muis").css('top', positie.top + 0 + 'px');
                            limitY = 40;
                        }
                    });    
            
            
            
            
            
                    break;
    }
      
    /*¨hier vindt u een tweede manier */
    
    /*
    
    if((a.which) === 37) {
            $("#muis").attr('src', 'img/links.gif');
                $("#muis").animate({ "left": "-=8px" }, 0);}
		if((a.which) === 38) {
            $("#muis").attr('src', 'img/omhoog.gif');
				$("#muis").animate({ "top": "-=8px" }, 0);}
		if((a.which) === 39) {
		  $("#muis").attr('src', 'img/rechts.gif');
				$("#muis").animate({ "left": "+=8px" }, 0);}
         if((a.which) === 40) {
            $("#muis").attr('src', 'img/beneden.gif');
				$("#muis").animate({ "top": "+=8px" }, 0); }
                */
});

});