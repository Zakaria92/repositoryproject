"use strict";
/*global $ */
$(document).keydown(function (a) {
   
    //alert(a.keyCode);
    
     switch (a.keyCode)
    {
        case 37:    $("#muis").attr('src', 'img/links.gif');
                    $("#muis").animate({ "left": "-=8px" }, 0);
                    break;
            
        case 38:    $("#muis").attr('src', 'img/omhoog.gif');
				    $("#muis").animate({ "top": "-=8px" }, 0);
                    break;
            
        case 39:    $("#muis").attr('src', 'img/rechts.gif');
				    $("#muis").animate({ "left": "+=8px" }, 0);
                    break;
            
        case 40:    $("#muis").attr('src', 'img/beneden.gif');
				    $("#muis").animate({ "top": "+=8px" }, 0);
                    break;
    }
      
    /*¨hier vindt u een tweede manier */
    
    /*
    
    if((a.which) === 37) {
            $("#muis").attr('src', 'img/links.gif');
                $("#muis").animate({ "left": "-=8px" }, 0);}
		if((a.which) === 38) {
            $("#muis").attr('src', 'img/omhoog.gif');
				$("#muis").animate({ "top": "-=8px" }, 0);}
		if((a.which) === 39) {
		  $("#muis").attr('src', 'img/rechts.gif');
				$("#muis").animate({ "left": "+=8px" }, 0);}
         if((a.which) === 40) {
            $("#muis").attr('src', 'img/beneden.gif');
				$("#muis").animate({ "top": "+=8px" }, 0); }
                */
});


